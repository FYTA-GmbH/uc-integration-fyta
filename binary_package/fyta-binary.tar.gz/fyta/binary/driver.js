// FYTA Plant Monitor integration for Unfolded Circle Remote Two
import * as api from '@unfoldedcircle/integration-api';
import './index.js';

console.log('FYTA Plant Monitor integration started');
